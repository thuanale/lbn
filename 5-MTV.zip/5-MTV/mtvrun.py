from MTVtk import *
from tkinter import Tk

root = Tk()
app = App(master=root)
app.mainloop()